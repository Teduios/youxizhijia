//
//  GameListModel.m
//  Day07_GameLive
//
//  Created by ios－54 on 15/10/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "GameListModel.h"

@implementation GameListModel

+ (NSDictionary *)objectClassInArray{
    return @{@"data":[GameListDataModel class]};
}

@end

@implementation GameListDataModel


@end
