//
//  MyTableViewController.m
//  资讯通·天下
//
//  Created by ios－54 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MyTableViewController.h"
#import "TuWanViewController.h"
#import "MiddleViewController.h"
#import "UMSocial.h"

@interface MyTableViewController ()<UMSocialUIDelegate>

@property (nonatomic, strong) UIView *customTabBar;

@end

@implementation MyTableViewController

+ (MyTableViewController *)defaultTabBar
{
    static MyTableViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [[MyTableViewController alloc]init];
    });
    return vc;
}

/*
- (UIView *)customTabBar
{
    if (!_customTabBar) {
        self.tabBar.hidden = YES;
        _customTabBar = [UIView new];
        self.tabBar.translucent = NO;
        [self.view addSubview:_customTabBar];
        [_customTabBar mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.height.mas_equalTo(self.tabBar.frame.size.height);
        }];
        _customTabBar.backgroundColor = kRGBColor(255, 255, 255);
        NSArray *itemNames = @[@"首页", @"dsf", @"简介"];
        NSArray *itemImages = @[[UIImage imageNamed:@"tabbar_company_home"], [UIImage imageNamed:@"middleImage"], [UIImage imageNamed:@"tabbar_position_oringin"]];
        UIView *lastView = nil;
        for (int i = 0; i < 3; i++) {
            UIButton *btn = [UIButton buttonWithType:0];
            [btn setTitle:itemNames[i] forState:0];
            [btn setImage:itemImages[i] forState:0];
            [_customTabBar addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.bottom.mas_equalTo(0);
                make.height.mas_equalTo(_customTabBar);
                if (lastView) {
                    make.left.mas_equalTo(lastView.mas_right).mas_equalTo(0);
                    make.width.mas_equalTo(lastView);
                }else {
                    make.left.mas_equalTo(0);
                }
                if (i == 2) {
                    make.right.mas_equalTo(0);
                }
            }];
            lastView = btn;
            [btn bk_addEventHandler:^(id sender) {
                self.selectedIndex = i;
            } forControlEvents:UIControlEventTouchUpInside];
        }
    }
    return _customTabBar;
}
 */

- (void)viewDidLoad {
    [super viewDidLoad];
    //self.customTabBar.hidden = NO;
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    UINavigationController *first = [TuWanViewController standardTuWanNavi];
    first.tabBarItem.title = @"游戏资讯";
    first.tabBarItem.image = [UIImage imageNamed:@"tabbar_company_home"];
    [first.tabBarItem setSelectedImage:[UIImage imageNamed:@"tabbar_company_home_select"]];
    
    UINavigationController *second = nil;
    second = kVCFromSb(@"StoryboardStart", @"Main");
    second.tabBarItem.title = @"游戏简介";
    second.tabBarItem.image = [UIImage imageNamed:@"tabbar_position_oringin"];
    [second.tabBarItem setSelectedImage:[UIImage imageNamed:@"tabbar_position_selected"]];
    
    MiddleViewController *middle = [[MiddleViewController alloc] init];
    [self addCenterButtonWithImage:[UIImage imageNamed:@"middleImage"] highlightImage:nil];
    
    self.tabBar.translucent = NO;
    
    self.viewControllers = @[first,middle,second];

}

- (void)viewDidLayoutSubviews
{
    [self addCenterButtonWithImage:nil highlightImage:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//添加中间按钮
- (void)addCenterButtonWithImage:(UIImage *)buttonImage highlightImage:(UIImage *)highlightImage
{
    self.middleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _middleBtn.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin;
    _middleBtn.frame = CGRectMake(0.0, 0.0, buttonImage.size.width, buttonImage.size.height);
    [_middleBtn addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
    [_middleBtn setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [_middleBtn setBackgroundImage:highlightImage forState:UIControlStateHighlighted];
    
    CGFloat heightDifference = buttonImage.size.height - self.tabBar.frame.size.height;
    if (heightDifference < 0)
        _middleBtn.center = self.tabBar.center;
    else
    {
        CGPoint center = self.tabBar.center;
        center.y = center.y - heightDifference/2.0;
        _middleBtn.center = center;
    }
    [self.view addSubview:_middleBtn];
}

- (void)buttonClick
{
    DDLogVerbose(@"点击中间按钮");
    //注意：分享到微信好友、微信朋友圈、微信收藏、QQ空间、QQ好友、来往好友、来往朋友圈、易信好友、易信朋友圈、Facebook、Twitter、Instagram等平台需要参考各自的集成方法
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:@"5632e65ae0f55a556a0013d9"
                                      shareText:@"你要分享的文字"
                                     shareImage:[UIImage imageNamed:@"icon.png"]
                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToWechatSession,UMShareToQQ,UMShareToSms,UMShareToEmail,UMShareToWechatTimeline,nil]
                                       delegate:self];
}

@end
