//
//  GameListViewController.h
//  Day07_GameLive
//
//  Created by ios－54 on 15/10/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameListViewController : UICollectionViewController

@end
