//
//  MiddleViewController.h
//  CustomTabBar
//
//  Created by zhangshuai on 15/11/5.
//  Copyright © 2015年 zhangshuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MiddleViewController : UIViewController

@end
