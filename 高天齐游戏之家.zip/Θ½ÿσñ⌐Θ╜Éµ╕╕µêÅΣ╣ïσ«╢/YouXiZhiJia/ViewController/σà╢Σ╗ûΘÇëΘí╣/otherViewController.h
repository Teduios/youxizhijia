//
//  otherViewController.h
//  YouXiZhiJia
//
//  Created by ios－54 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface otherViewController : UIViewController

+ (UINavigationController *)defaultOtherVC;

@end
